package com.zajil.chat.data.db

import androidx.room.*

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val content: String,
    val encryptedPayload: String?,
    val iv: String,
    val salt: String,
    val mediaType: String, // "text", "image", "audio", "video", "file"
    val mediaFilePath: String?,
    val timestamp: Long,
    val isPasswordProtected: Boolean
)

@Entity(tableName = "blocked_devices")
data class BlockedDeviceEntity(
    @PrimaryKey val macAddress: String,
    val deviceName: String,
    val blockedAt: Long,
    val reason: String?
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :convId ORDER BY timestamp ASC")
    suspend fun getMessagesByConversation(convId: String): List<MessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity)

    @Query("DELETE FROM messages WHERE conversationId = :convId")
    suspend fun clearConversation(convId: String)
}

@Dao
interface BlockedDeviceDao {
    @Query("SELECT * FROM blocked_devices")
    suspend fun getAllBlocked(): List<BlockedDeviceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun blockDevice(device: BlockedDeviceEntity)

    @Delete
    suspend fun unblockDevice(device: BlockedDeviceEntity)

    @Query("SELECT EXISTS(SELECT 1 FROM blocked_devices WHERE macAddress = :mac)")
    suspend fun isBlocked(mac: String): Boolean
}

@Database(entities = [MessageEntity::class, BlockedDeviceEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun blockedDeviceDao(): BlockedDeviceDao
}
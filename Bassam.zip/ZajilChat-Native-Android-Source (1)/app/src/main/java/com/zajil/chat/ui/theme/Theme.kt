package com.zajil.chat.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Sky50 = Color(0xFFF0F9FF)
val Sky100 = Color(0xFFE0F2FE)
val Sky500 = Color(0xFF0EA5E9)
val Sky600 = Color(0xFF0284C7)
val Sky700 = Color(0xFF0369A1)
val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)

private val LightColorScheme = lightColorScheme(
    primary = Sky600,
    onPrimary = Color.White,
    primaryContainer = Sky100,
    onPrimaryContainer = Sky700,
    background = Sky50,
    onBackground = Slate900,
    surface = Color.White,
    onSurface = Slate900
)

private val DarkColorScheme = darkColorScheme(
    primary = Sky500,
    onPrimary = Slate900,
    primaryContainer = Color(0xFF082F49),
    onPrimaryContainer = Sky100,
    background = Color(0xFF0B1320),
    onBackground = Color(0xFFF1F5F9),
    surface = Slate800,
    onSurface = Color(0xFFF1F5F9)
)

@Composable
fun ZajilTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
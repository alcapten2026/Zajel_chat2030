package com.zajil.chat.crypto

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * محرك التشفير العسكري الأصلي لتطبيق «زاجل شات»
 * AES-256-GCM مع متجه تهيئة 96-بت ووسم مصادقة 128-بت واشتقاق PBKDF2WithHmacSHA256
 */
object NativeCryptoEngine {

    private const val ALGORITHM = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BITS = 128
    private const val IV_LENGTH_BYTES = 12
    private const val SALT_LENGTH_BYTES = 16
    private const val ITERATIONS = 100000
    private const val KEY_LENGTH_BITS = 256

    private val secureRandom = SecureRandom()

    data class EncryptedEnvelope(
        val ciphertextBase64: String,
        val ivBase64: String,
        val saltBase64: String,
        val isPasswordProtected: Boolean
    )

    /**
     * اشتقاق مفتاح AES-256 من كلمة المرور أو المعرف المشترك عبر PBKDF2
     */
    fun deriveKey(passphrase: String, salt: ByteArray): SecretKey {
        val spec = PBEKeySpec(passphrase.toCharArray(), salt, ITERATIONS, KEY_LENGTH_BITS)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val secretBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(secretBytes, "AES")
    }

    /**
     * تشفير نصوص أو بايتات الوسائط بـ AES-256-GCM
     */
    fun encrypt(plainBytes: ByteArray, passphrase: String, isPasswordProtected: Boolean = false): EncryptedEnvelope {
        val salt = ByteArray(SALT_LENGTH_BYTES).also { secureRandom.nextBytes(it) }
        val iv = ByteArray(IV_LENGTH_BYTES).also { secureRandom.nextBytes(it) }

        val key = deriveKey(passphrase, salt)
        val cipher = Cipher.getInstance(ALGORITHM)
        val gcmSpec = GCMParameterSpec(TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec)

        val encryptedBytes = cipher.doFinal(plainBytes)

        return EncryptedEnvelope(
            ciphertextBase64 = Base64.encodeToString(encryptedBytes, Base64.NO_WRAP),
            ivBase64 = Base64.encodeToString(iv, Base64.NO_WRAP),
            saltBase64 = Base64.encodeToString(salt, Base64.NO_WRAP),
            isPasswordProtected = isPasswordProtected
        )
    }

    /**
     * فك تشفير البيانات والتحقق من سلامتها بوسم GCM 128-bit
     */
    @Throws(Exception::class)
    fun decrypt(envelope: EncryptedEnvelope, passphrase: String): ByteArray {
        val encryptedBytes = Base64.decode(envelope.ciphertextBase64, Base64.NO_WRAP)
        val iv = Base64.decode(envelope.ivBase64, Base64.NO_WRAP)
        val salt = Base64.decode(envelope.saltBase64, Base64.NO_WRAP)

        val key = deriveKey(passphrase, salt)
        val cipher = Cipher.getInstance(ALGORITHM)
        val gcmSpec = GCMParameterSpec(TAG_LENGTH_BITS, iv)
        cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec)

        return cipher.doFinal(encryptedBytes)
    }
}
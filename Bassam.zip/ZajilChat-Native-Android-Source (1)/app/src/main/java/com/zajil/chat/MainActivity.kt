package com.zajil.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.zajil.chat.ui.theme.ZajilTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // فرض الاتجاه من اليمين إلى اليسار (RTL) للغة العربية الأصيلة
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                ZajilTheme {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        ZajilMainScreen()
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZajilMainScreen() {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("زاجل شات 🕊️ (بلوتوث أوفلاين)") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0284C7),
                    titleContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF0F9FF))
        ) {
            Text(
                text = "مرحباً بك في زاجل شات الأصلي للأندرويد",
                style = MaterialTheme.typography.titleLarge,
                color = Color(0xFF0F172A)
            )
        }
    }
}
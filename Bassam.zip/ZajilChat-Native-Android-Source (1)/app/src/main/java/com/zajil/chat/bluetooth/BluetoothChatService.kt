package com.zajil.chat.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/**
 * خدمة البلوتوث الأصلية لتطبيق «زاجل شات»
 * تستخدم مآخذ RFCOMM الثنائية المباشرة مع سيرفر استماع وخيط اتصال متزامن
 */
class BluetoothChatService(private val context: Context) {

    companion object {
        private const val TAG = "ZajilBluetoothService"
        private const val APP_NAME = "ZajilChatNative"
        // المعرّف الفريد العالمي القياسي SPP / RFCOMM
        val ZAJIL_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        const val STATE_NONE = 0
        const val STATE_LISTEN = 1
        const val STATE_CONNECTING = 2
        const val STATE_CONNECTED = 3
    }

    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()
    private var acceptThread: AcceptThread? = null
    private var connectThread: ConnectThread? = null
    private var connectedThread: ConnectedThread? = null

    var state = STATE_NONE
        private set

    // تدفق الرسائل المستلمة المباشرة
    private val _incomingMessages = MutableSharedFlow<ByteArray>(replay = 0)
    val incomingMessages = _incomingMessages.asSharedFlow()

    @Synchronized
    fun startListening() {
        connectThread?.cancel(); connectThread = null
        connectedThread?.cancel(); connectedThread = null

        if (acceptThread == null) {
            acceptThread = AcceptThread()
            acceptThread?.start()
        }
        state = STATE_LISTEN
        Log.d(TAG, "زاجل: بدأ خادم الاستماع لطلبات البلوتوث الواردة...")
    }

    @SuppressLint("MissingPermission")
    @Synchronized
    fun connect(device: BluetoothDevice) {
        if (state == STATE_CONNECTING) {
            connectThread?.cancel(); connectThread = null
        }
        connectedThread?.cancel(); connectedThread = null

        connectThread = ConnectThread(device)
        connectThread?.start()
        state = STATE_CONNECTING
    }

    @Synchronized
    fun connected(socket: BluetoothSocket, device: BluetoothDevice) {
        connectThread?.cancel(); connectThread = null
        connectedThread?.cancel(); connectedThread = null
        acceptThread?.cancel(); acceptThread = null

        connectedThread = ConnectedThread(socket)
        connectedThread?.start()
        state = STATE_CONNECTED
        Log.i(TAG, "زاجل: تم الاتصال بنجاح بالجهاز ${device.name} [${device.address}]")
    }

    fun write(out: ByteArray) {
        var r: ConnectedThread?
        synchronized(this) {
            if (state != STATE_CONNECTED) return
            r = connectedThread
        }
        r?.write(out)
    }

    @SuppressLint("MissingPermission")
    private inner class AcceptThread : Thread() {
        private val mmServerSocket: BluetoothServerSocket? by lazy {
            try {
                bluetoothAdapter?.listenUsingRfcommWithServiceRecord(APP_NAME, ZAJIL_UUID)
            } catch (e: IOException) {
                Log.e(TAG, "فشل إنشاء مأخذ الخادم", e)
                null
            }
        }

        override fun run() {
            var socket: BluetoothSocket?
            while (state != STATE_CONNECTED) {
                socket = try {
                    mmServerSocket?.accept()
                } catch (e: IOException) {
                    break
                }
                if (socket != null) {
                    synchronized(this@BluetoothChatService) {
                        when (state) {
                            STATE_LISTEN, STATE_CONNECTING -> connected(socket, socket.remoteDevice)
                            STATE_NONE, STATE_CONNECTED -> {
                                try { socket.close() } catch (e: IOException) {}
                            }
                        }
                    }
                }
            }
        }

        fun cancel() {
            try { mmServerSocket?.close() } catch (e: IOException) {}
        }
    }

    @SuppressLint("MissingPermission")
    private inner class ConnectThread(private val mmDevice: BluetoothDevice) : Thread() {
        private val mmSocket: BluetoothSocket? by lazy {
            try {
                mmDevice.createRfcommSocketToServiceRecord(ZAJIL_UUID)
            } catch (e: IOException) {
                null
            }
        }

        override fun run() {
            bluetoothAdapter?.cancelDiscovery()
            try {
                mmSocket?.connect()
            } catch (e: IOException) {
                try { mmSocket?.close() } catch (e2: IOException) {}
                startListening()
                return
            }
            synchronized(this@BluetoothChatService) { connectThread = null }
            connected(mmSocket!!, mmDevice)
        }

        fun cancel() {
            try { mmSocket?.close() } catch (e: IOException) {}
        }
    }

    private inner class ConnectedThread(private val mmSocket: BluetoothSocket) : Thread() {
        private val mmInStream: InputStream = mmSocket.inputStream
        private val mmOutStream: OutputStream = mmSocket.outputStream
        private val mmBuffer: ByteArray = ByteArray(32768)

        override fun run() {
            var numBytes: Int
            while (true) {
                try {
                    numBytes = mmInStream.read(mmBuffer)
                    val readData = mmBuffer.copyOf(numBytes)
                    _incomingMessages.tryEmit(readData)
                } catch (e: IOException) {
                    Log.d(TAG, "انقطع الاتصال بالجهاز البعيد", e)
                    startListening()
                    break
                }
            }
        }

        fun write(buffer: ByteArray) {
            try {
                mmOutStream.write(buffer)
                mmOutStream.flush()
            } catch (e: IOException) {
                Log.e(TAG, "خطأ أثناء إرسال البيانات عبر البلوتوث", e)
            }
        }

        fun cancel() {
            try { mmSocket.close() } catch (e: IOException) {}
        }
    }
}